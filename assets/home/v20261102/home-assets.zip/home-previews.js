(() => {
  const section = document.querySelector('.home-picks');
  const button = document.getElementById('previewToggle');
  const previews = [...document.querySelectorAll('.skill-preview')];
  if (!section || !button || !previews.length) return;
  let paused = false;
  const videos = [...section.querySelectorAll('video')];
  const motionPreference = matchMedia('(prefers-reduced-motion: reduce)');
  videos.forEach(video => {
    const ready = () => { if(video.readyState >= 2) video.classList.add('video-ready'); };
    video.addEventListener('loadeddata', ready);
    video.addEventListener('playing', ready);
    video.addEventListener('error', () => video.classList.remove('video-ready'));
    ready();
  });
  section.querySelectorAll('.skill-shelf').forEach(shelf => {
    const track = shelf.querySelector('.shelf-track');
    const previous = shelf.querySelector('[data-shelf-step="-1"]');
    const next = shelf.querySelector('[data-shelf-step="1"]');
    const sync = () => {
      previous.disabled = track.scrollLeft < 5;
      next.disabled = track.scrollLeft >= track.scrollWidth - track.clientWidth - 5;
      track.dataset.prev = String(!previous.disabled);
      track.dataset.next = String(!next.disabled);
    };
    const move = (direction, keyboard) => {
      const card = track.querySelector('.home-pick');
      const stride = card.getBoundingClientRect().width + parseFloat(getComputedStyle(track).gap);
      const distance = stride * Math.max(1, Math.floor((track.clientWidth + parseFloat(getComputedStyle(track).gap)) / stride));
      track.scrollBy({left:direction * distance, behavior:keyboard || motionPreference.matches ? 'instant' : 'smooth'});
    };
    shelf.querySelectorAll('[data-shelf-step]').forEach(control => control.addEventListener('click', event => move(Number(control.dataset.shelfStep), event.detail === 0)));
    track.addEventListener('keydown', event => {
      if(event.target !== track) return;
      if(event.key === 'ArrowLeft' || event.key === 'ArrowRight') {
        event.preventDefault(); move(event.key === 'ArrowRight' ? 1 : -1, true);
      } else if(event.key === 'Home' || event.key === 'End') {
        event.preventDefault();track.scrollTo({left:event.key === 'Home' ? 0 : track.scrollWidth,behavior:'instant'});
      }
    });
    track.addEventListener('scroll', sync, {passive:true});
    if('ResizeObserver' in window) new ResizeObserver(sync).observe(track);
    sync();
  });
  function syncVideo(video) {
    const reduce = motionPreference.matches;
    if(paused || document.hidden || reduce || video.closest('.preview-offscreen')) video.pause();
    else video.play().catch(()=>{});
  }
  motionPreference.addEventListener?.('change',()=>videos.forEach(syncVideo));
  if ('ResizeObserver' in window) {
    const sizes = new ResizeObserver(entries=>entries.forEach(entry=>{
      const frame=entry.target.querySelector('iframe');
      if(frame)frame.style.transform='scale('+(entry.contentRect.width/1100)+')';
    }));
    section.querySelectorAll('.artifact-frame').forEach(frame=>sizes.observe(frame));
  }
  button.addEventListener('click', () => {
    paused = !paused;
    section.classList.toggle('previews-paused', paused);
    button.setAttribute('aria-pressed', String(paused));
    button.textContent = paused ? button.dataset.resume : button.dataset.pause;
    videos.forEach(syncVideo);
  });
  const visibility = () => {section.classList.toggle('previews-hidden', document.hidden);videos.forEach(syncVideo);};
  document.addEventListener('visibilitychange', visibility);
  visibility();
  if ('IntersectionObserver' in window) {
    previews.forEach(preview => preview.classList.add('preview-offscreen'));
    const observer = new IntersectionObserver(entries => entries.forEach(entry => {
      entry.target.classList.toggle('preview-offscreen', !entry.isIntersecting);
      entry.target.querySelectorAll('video').forEach(syncVideo);
    }), {threshold: 0});
    previews.forEach(preview => observer.observe(preview));
  }
})();
