(() => {
  const button=document.getElementById('copy-start-prompt');
  const prompt=document.getElementById('start-prompt');
  const status=document.querySelector('.start-copy-status');
  if(!button || !prompt || !status)return;
  let reset;
  button.addEventListener('click',async()=>{
    clearTimeout(reset);
    try{
      await navigator.clipboard.writeText(prompt.textContent.trim());
      button.querySelector('span').textContent=button.dataset.success;
      status.textContent=button.dataset.success;
      reset=setTimeout(()=>{button.querySelector('span').textContent=button.dataset.label;status.textContent='';},2400);
    }catch{
      status.textContent=button.dataset.error;
      prompt.focus();
      const selection=getSelection(),range=document.createRange();range.selectNodeContents(prompt);selection.removeAllRanges();selection.addRange(range);
    }
  });
})();
